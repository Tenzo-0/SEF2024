$(document).ready(function() {
    var recorder;
    var audioBlob;

    // Update duration value display
    $('#duration').on('input', function() {
        $('#duration-value').text($(this).val());
    });

    // Handle form submission
    $('#musicgen-form').on('submit', function(e) {
        e.preventDefault();

        // Hide result and show loading
        $('#result').hide();
        $('#loading').show();

        var formData = new FormData(this);

        // If audio was recorded, append it to the form data
        if (audioBlob) {
            formData.append('melody', audioBlob, 'recorded_audio.wav');
        }

        $.ajax({
            url: '/start_generation',
            type: 'POST',
            data: formData,
            contentType: false,
            processData: false,
            success: function(response) {
                checkGenerationStatus();
            },
            error: function(xhr) {
                // Hide loading
                $('#loading').hide();

                var errorMessage = 'An error occurred while starting generation.';
                if (xhr.responseJSON && xhr.responseJSON.error) {
                    errorMessage = xhr.responseJSON.error;
                }
                alert('Error: ' + errorMessage);
            }
        });
    });

    // Function to check generation status
    function checkGenerationStatus() {
        $.ajax({
            url: '/check_status',
            type: 'GET',
            success: function(response) {
                if (response.status === 'Generating') {
                    setTimeout(checkGenerationStatus, 2000);
                } else if (response.status === 'Completed') {
                    // Fetch the generated audio
                    fetchGeneratedAudio();
                } else {
                    $('#loading').hide();
                    alert('An error occurred during music generation.');
                    console.error('Generation status:', response.status);
                }
            },
            error: function(xhr, status, error) {
                $('#loading').hide();
                alert('An error occurred while checking generation status.');
                console.error('Error checking status:', error);
            }
        });
    }

    // Function to fetch generated audio
    function fetchGeneratedAudio() {
        $.ajax({
            url: '/get_audio',
            type: 'GET',
            xhrFields: {
                responseType: 'blob'  // Important to handle the binary data
            },
            success: function(blob) {
                // Hide loading
                $('#loading').hide();

                // Create a blob URL for the audio
                var audioUrl = URL.createObjectURL(blob);
                $('#generated-audio').attr('src', audioUrl);
                $('#download-link').attr('href', audioUrl).attr('download', 'generated_music.wav').show();
                $('#result').show();

                // Cleanup on the server
                $.ajax({
                    url: '/cleanup',
                    type: 'POST'
                });
            },
            error: function() {
                $('#loading').hide();
                alert('An error occurred while fetching the generated audio.');
            }
        });
    }

    // Interrupt button handler
    $('#interrupt-btn').on('click', function() {
        $.ajax({
            url: '/interrupt',
            type: 'POST',
            success: function(response) {
                alert('Generation interrupted.');
            },
            error: function() {
                alert('An error occurred while sending interrupt request.');
            }
        });
    });

    // Recording functionality
    var isRecording = false;
    var gumStream;

    $('#record-btn').on('click', function() {
        navigator.mediaDevices.getUserMedia({ audio: true }).then(function(stream) {
            gumStream = stream;
            var audioContext = new (window.AudioContext || window.webkitAudioContext)();
            var input = audioContext.createMediaStreamSource(stream);
            recorder = new Recorder(input, { numChannels: 1 });
            recorder.record();

            isRecording = true;
            $('#record-btn').attr('disabled', true);
            $('#stop-btn').attr('disabled', false);
        }).catch(function(err) {
            alert('Microphone access denied.');
        });
    });

    $('#stop-btn').on('click', function() {
        recorder.stop();
        gumStream.getAudioTracks()[0].stop();

        recorder.exportWAV(function(blob) {
            audioBlob = blob;
            var url = URL.createObjectURL(blob);
            $('#recorded-audio').attr('src', url).show();
        });

        isRecording = false;
        $('#record-btn').attr('disabled', false);
        $('#stop-btn').attr('disabled', true);
    });
});
