import os
from flask import Flask, request, send_file, jsonify, render_template
import torch
import io
import traceback
from datetime import datetime
from threading import Thread, Event
from audiocraft.models import MusicGen
import torchaudio
import threading  # For thread-safe model loading
import requests
import json

app = Flask(__name__)

# Device setup
if torch.cuda.is_available():
    device = 'cuda'
else:
    device = 'cpu'

# Global variables
generation_thread = None
interrupt_event = Event()
generated_audio_data = None

# Model cache for pre-loaded models
MODEL_CACHE = {}
MODEL_CACHE_LOCK = threading.Lock()

def translate_text(text, source_language='vi', target_language='en'):
    url = "https://microsoft-translator-text-api3.p.rapidapi.com/translate"

    querystring = {
        "textType": "plain",
        "from": source_language,
        "to": target_language
    }

    payload = [{
        "Text": text
    }]
    
    headers = {
    	"x-rapidapi-key": "9ad56b4739msh46f21e45764ab3cp1092e4jsn6cc0aa5fa2c2",
    	"x-rapidapi-host": "microsoft-translator-text-api3.p.rapidapi.com",
    	"Content-Type": "application/json"
    }

    response = requests.post(url, json=payload, headers=headers, params=querystring)

    # Check if the request was successful
    if response.status_code == 200:
        translations = response.json()
        print(translations[0]['translations'][0]['text'])
        return translations[0]['translations'][0]['text']
    else:
        print("Error:", response.status_code, response.text)
        return None

def load_custom_musicgen_model(custom_model_path, device, base_model_name):
    from audiocraft.models import MusicGen
    import torch
    import os

    # Load the base pre-trained model
    model = MusicGen.get_pretrained(base_model_name)

    # Paths to your state dictionaries
    state_dict_path = os.path.join(custom_model_path, 'state_dict.bin')
    compression_state_dict_path = os.path.join(custom_model_path, 'compression_state_dict.bin')

    # Load the state dictionaries
    state_dict = torch.load(state_dict_path, map_location=device)
    compression_state_dict = torch.load(compression_state_dict_path, map_location=device)

    # Extract the actual state dict if nested under 'best_state'
    if 'best_state' in state_dict:
        model_state_dict = state_dict['best_state']
    else:
        model_state_dict = state_dict

    if 'best_state' in compression_state_dict:
        compression_model_state_dict = compression_state_dict['best_state']
    else:
        compression_model_state_dict = compression_state_dict

    # Remove any prefixes from the keys
    model_state_dict = {k.replace('module.', ''): v for k, v in model_state_dict.items()}
    compression_model_state_dict = {k.replace('module.', ''): v for k, v in compression_model_state_dict.items()}

    # Load the state dicts into the respective submodules
    model.lm.load_state_dict(model_state_dict, strict=False)
    model.compression_model.load_state_dict(compression_model_state_dict, strict=False)

    return model

def generate_music(text, melody, duration, top_k, temperature, interrupt_event, custom_model_path):
    global generated_audio_data, MODEL_CACHE, MODEL_CACHE_LOCK, device

    try:
        print("Starting music generation...")
         # Validate and log generation parameters
        if top_k < 1 or top_k > 500:
            print(f"Invalid top_k value: {top_k}. Setting to default 250.")
            top_k = 250
        if temperature <= 0 or temperature > 2.0:
            print(f"Invalid temperature value: {temperature}. Setting to default 1.0.")
            temperature = 1.0

        print(f"Generation parameters - Duration: {duration}, Top-k: {top_k}, Temperature: {temperature}")

        # Load the custom model
        model_key = custom_model_path
        with MODEL_CACHE_LOCK:
            if model_key in MODEL_CACHE:
                model = MODEL_CACHE[model_key]
                print(f"Using cached custom model from {custom_model_path}")
            else:
                try:
                    print(f"Loading custom model from {custom_model_path}")
                    # Specify the base model name used during fine-tuning
                    base_model_name = 'facebook/musicgen-stereo-small'  # Replace with your base model
                    model = load_custom_musicgen_model(custom_model_path, device, base_model_name)
                    MODEL_CACHE[model_key] = model
                except Exception as e:
                    print(f"Error loading custom model: {e}")
                    traceback.print_exc()
                    raise ValueError(f"Failed to load custom model from {custom_model_path}")

        # Set generation parameters
        model.set_generation_params(duration=duration, top_k=top_k, temperature=temperature)

        # Custom progress callback to handle interruption
        def progress_callback(generated, total):
            if interrupt_event.is_set():
                raise Exception("Generation interrupted by user.")

        model.set_custom_progress_callback(progress_callback)

        # Prepare the text input
        text_inputs = [text]

        # Generate music
        if melody:
            print("Generating with melody...")
            melody_sample_rate, melody_waveform = melody
            # Ensure melody_waveform is on the same device as the model
            melody_waveform = melody_waveform.to(model.device)
            melody_input = (melody_sample_rate, melody_waveform)
            generated_audio = model.generate_with_chroma(text_inputs, [melody_input], progress=True)
        else:
            print("Generating without melody...")
            generated_audio = model.generate(text_inputs, progress=True)

        # Save generated audio to a BytesIO object
        from io import BytesIO
        generated_audio_data = BytesIO()
        print("Saving generated audio to BytesIO object")
        torchaudio.save(generated_audio_data, generated_audio[0].cpu(), model.sample_rate, format='wav')
        generated_audio_data.seek(0)
        print("Music generation completed successfully.")

    except Exception as e:
        generated_audio_data = None
        print(f"Error during music generation: {e}")
        traceback.print_exc()

@app.route('/')
def index():
    current_year = datetime.now().year
    return render_template('index.html', current_year=current_year)

@app.route('/start_generation', methods=['POST'])
def start_generation():
    global generation_thread, interrupt_event, generated_audio_data
    interrupt_event.clear()
    generated_audio_data = None

    # Get form data
    text = request.form.get('text')
    if not text:
        return jsonify({'error': 'No text provided'}), 400

    # Translate the text from Vietnamese to English
    translated_text = translate_text(text)

    try:
        duration = float(request.form.get('duration', 10))
        top_k = int(request.form.get('top_k', 250))
        temperature = float(request.form.get('temperature', 1.0))
    except ValueError:
        return jsonify({'error': 'Invalid parameter values'}), 400

    # Set the custom model path directly
    custom_model_path = "/home/user/checkpoints/finetune"

    # Get optional melody input
    melody = None
    if 'melody' in request.files and request.files['melody'].filename != '':
        melody_file = request.files['melody']
        melody_bytes = melody_file.read()
        melody_waveform, melody_sample_rate = torchaudio.load(io.BytesIO(melody_bytes))
        # Ensure melody_waveform is in the correct format
        if melody_waveform.dim() == 1:
            melody_waveform = melody_waveform.unsqueeze(0)
        melody = (melody_sample_rate, melody_waveform)

    # Start music generation in a separate thread
    generation_thread = Thread(target=generate_music, args=(
        translated_text, melody, duration, top_k, temperature, interrupt_event, custom_model_path))
    generation_thread.start()

    return jsonify({'status': 'Generation started'}), 200

@app.route('/check_status', methods=['GET'])
def check_status():
    global generation_thread, generated_audio_data
    if generation_thread and generation_thread.is_alive():
        return jsonify({'status': 'Generating'}), 200
    elif generated_audio_data is not None:
        return jsonify({'status': 'Completed'}), 200
    elif generation_thread:
        return jsonify({'status': 'Error'}), 500
    else:
        return jsonify({'status': 'NotStarted'}), 200

@app.route('/get_audio', methods=['GET'])
def get_audio():
    global generated_audio_data
    if generated_audio_data is not None:
        # Serve the audio data
        return send_file(generated_audio_data, mimetype='audio/wav', as_attachment=False)
    else:
        return jsonify({'error': 'No audio available'}), 404

@app.route('/interrupt', methods=['POST'])
def interrupt():
    global interrupt_event
    interrupt_event.set()
    return jsonify({'status': 'Interrupt requested'}), 200

@app.route('/cleanup', methods=['POST'])
def cleanup():
    global generated_audio_data
    generated_audio_data = None
    return jsonify({'status': 'Cleaned up'}), 200

if __name__ == '__main__':
    app.run(debug=True)
